package it.univpm.TweetGeo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TweetGeoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TweetGeoApplication.class, args);
	}

}
