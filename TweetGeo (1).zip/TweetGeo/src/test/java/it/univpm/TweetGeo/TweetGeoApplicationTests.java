package it.univpm.TweetGeo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TweetGeoApplicationTests {

	@Test
	void contextLoads() {
	}

}
